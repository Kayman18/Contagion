Contagion USB Editor
====================
Open Contagion-USB-Editor.html in Chrome or Edge. Connect the FM-1 with a
USB-C data cable, click Connect USB MIDI and allow MIDI and SysEx access.
Select the Contagion or FM-1 MIDI input and output if needed.

If the browser blocks MIDI for a local file, serve this extracted directory
on your own computer. With Python installed, open a terminal in the folder:

  python -m http.server 8765 --bind 127.0.0.1

Then open http://127.0.0.1:8765/Contagion-USB-Editor.html in Chrome or Edge.
On Windows, use py instead of python if that is how Python is installed.

Factory navigation is matched to Contagion 1.1 All Banks 8V. Recall factory
sound sends the selected bank and program to the FM-1. Load into editor opens
its settings for editing. CC labels identify which controls can send changes
live. Patch-only controls are applied by writing and recalling a USER slot.
MIDI permission can be denied and the editor still works offline.

To preserve a USER patch, read it and export its .vcp before overwriting.
After a verified write, open SCL → USER PATCHES, use K1 to select the slot, and K2 to recall it
on the FM-1. The firmware protocol reads and writes stored USER slots.
It does not report the FM-1's active patch or recall a USER slot remotely.
Play the on-screen keys to send notes and listen through the FM-1 audio out.

This is an offline HTML file with the factory data built in. No account or
internet connection is required. The editor and firmware SysEx round-trip
were checked in simulation. Physical USB MIDI operation remains unverified.
